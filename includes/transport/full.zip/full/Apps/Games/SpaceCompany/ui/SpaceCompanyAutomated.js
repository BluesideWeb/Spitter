// Build UI
var linebreak1 = document.createElement("BR");
var linebreak2 = document.createElement("BR");
var linebreak3 = document.createElement("BR");
var linebreak4 = document.createElement("BR");
var linebreak5 = document.createElement("BR");
var linebreak6 = document.createElement("BR");
var linebreak7 = document.createElement("BR");
var linebreak8 = document.createElement("BR");
var linebreak9 = document.createElement("BR");
var linebreak10 = document.createElement("BR");
var linebreak11 = document.createElement("BR");
var linebreak12 = document.createElement("BR");
var linebreak13 = document.createElement("BR");
var linebreak14 = document.createElement("BR");
var linebreak15 = document.createElement("BR");
var linebreak16 = document.createElement("BR");
var linebreak17 = document.createElement("BR");
var linebreak18 = document.createElement("BR");
var linebreak19 = document.createElement("BR");
var linebreak20 = document.createElement("BR");
var linebreak21 = document.createElement("BR");
var linebreak22 = document.createElement("BR");
var linebreak23 = document.createElement("BR");
var linebreak24 = document.createElement("BR");
var linebreak25 = document.createElement("BR");
var linebreak26 = document.createElement("BR");
var linebreak27 = document.createElement("BR");
var linebreak28 = document.createElement("BR");
var linebreak29 = document.createElement("BR");
var linebreak30 = document.createElement("BR");

var GainResources = document.createElement('SPAN');
var GainResourcesCheckbox = document.createElement('INPUT');
var GainResourcesText = document.createTextNode('Auto gain resources \xa0\xa0\xa0\xa0\xa0');
GainResourcesCheckbox.setAttribute('type', 'checkbox');
GainResources.appendChild(GainResourcesText);
GainResources.appendChild(GainResourcesCheckbox);
GainResources.appendChild(linebreak1);
document.getElementById('donatingTab').appendChild(GainResources);

var ExpandStorage = document.createElement('SPAN');
var ExpandStorageCheckbox = document.createElement('INPUT');
var ExpandStorageText = document.createTextNode('Auto upgrade Storage when full \xa0\xa0\xa0\xa0\xa0');
ExpandStorageCheckbox.setAttribute('type', 'checkbox');
ExpandStorage.appendChild(ExpandStorageText);
ExpandStorage.appendChild(ExpandStorageCheckbox);
ExpandStorage.appendChild(linebreak2);
document.getElementById('donatingTab').appendChild(ExpandStorage);

var achievementBuilder = document.createElement('SPAN');
var achievementBuilderCheckbox = document.createElement('INPUT');
var achievementBuilderText = document.createTextNode('Auto build Machines for Achievements (Energy dependancy added) \xa0\xa0\xa0\xa0\xa0');
achievementBuilderCheckbox.setAttribute('type', 'checkbox');
achievementBuilder.appendChild(achievementBuilderText);
achievementBuilder.appendChild(achievementBuilderCheckbox);
achievementBuilder.appendChild(linebreak3);
document.getElementById('donatingTab').appendChild(achievementBuilder);

var T1Amount = document.createElement('SPAN');
var T1AmountTextBox = document.createElement('INPUT');
var T1AmountText = document.createTextNode('\xa0\xa0\xa0 Amount of T1 Structures to build: \xa0\xa0\xa0\xa0\xa0');
T1AmountTextBox.setAttribute('type', 'text');
T1Amount.appendChild(T1AmountText);
T1Amount.appendChild(T1AmountTextBox);
T1Amount.appendChild(linebreak4);
document.getElementById('donatingTab').appendChild(T1Amount);

var T2Amount = document.createElement('SPAN');
var T2AmountTextBox = document.createElement('INPUT');
var T2AmountText = document.createTextNode('\xa0\xa0\xa0 Amount of T2 Structures to build: \xa0\xa0\xa0\xa0\xa0');
T2AmountTextBox.setAttribute('type', 'text');
T2Amount.appendChild(T2AmountText);
T2Amount.appendChild(T2AmountTextBox);
T2Amount.appendChild(linebreak5);
document.getElementById('donatingTab').appendChild(T2Amount);

var T3Amount = document.createElement('SPAN');
var T3AmountTextBox = document.createElement('INPUT');
var T3AmountText = document.createTextNode('\xa0\xa0\xa0 Amount of T3 Structures to build: \xa0\xa0\xa0\xa0\xa0');
T3AmountTextBox.setAttribute('type', 'text');
T3Amount.appendChild(T3AmountText);
T3Amount.appendChild(T3AmountTextBox);
T3Amount.appendChild(linebreak6);
document.getElementById('donatingTab').appendChild(T3Amount);

var T4Amount = document.createElement('SPAN');
var T4AmountTextBox = document.createElement('INPUT');
var T4AmountText = document.createTextNode('\xa0\xa0\xa0 Amount of T4 Structures to build: \xa0\xa0\xa0\xa0\xa0');
T4AmountTextBox.setAttribute('type', 'text');
T4Amount.appendChild(T4AmountText);
T4Amount.appendChild(T4AmountTextBox);
T4Amount.appendChild(linebreak7);
document.getElementById('donatingTab').appendChild(T4Amount);

var T5Amount = document.createElement('SPAN');
var T5AmountTextBox = document.createElement('INPUT');
var T5AmountText = document.createTextNode('\xa0\xa0\xa0 Amount of T5 Structures to build: \xa0\xa0\xa0\xa0\xa0');
T5AmountTextBox.setAttribute('type', 'text');
T5Amount.appendChild(T5AmountText);
T5Amount.appendChild(T5AmountTextBox);
T5Amount.appendChild(linebreak8);
document.getElementById('donatingTab').appendChild(T5Amount);

var SciBuilder = document.createElement('SPAN');
var SciBuilderCheckbox = document.createElement('INPUT');
var SciBuilderText = document.createTextNode('Auto build Science Buildings and Research Techs \xa0\xa0\xa0\xa0\xa0');
SciBuilderCheckbox.setAttribute('type', 'checkbox');
SciBuilder.appendChild(SciBuilderText);
SciBuilder.appendChild(SciBuilderCheckbox);
SciBuilder.appendChild(linebreak9);
document.getElementById('donatingTab').appendChild(SciBuilder);

var PMBuilder = document.createElement('SPAN');
var PMBuilderCheckbox = document.createElement('INPUT');
var PMBuilderText = document.createTextNode('Auto build Plasma and Meteorite T1,2,3 buildings \xa0\xa0\xa0\xa0\xa0');
PMBuilderCheckbox.setAttribute('type', 'checkbox');
PMBuilder.appendChild(PMBuilderText);
PMBuilder.appendChild(PMBuilderCheckbox);
PMBuilder.appendChild(linebreak10);
document.getElementById('donatingTab').appendChild(PMBuilder);

var DSBuilder = document.createElement('SPAN');
var DSBuilderCheckbox = document.createElement('INPUT');
var DSBuilderText = document.createTextNode('Auto build Dyson Rings and Swarms \xa0\xa0\xa0\xa0\xa0');
DSBuilderCheckbox.setAttribute('type', 'checkbox');
DSBuilder.appendChild(DSBuilderText);
DSBuilder.appendChild(DSBuilderCheckbox);
DSBuilder.appendChild(linebreak11);
document.getElementById('donatingTab').appendChild(DSBuilder);

var spherePush = document.createElement('SPAN');
var spherePushCheckbox = document.createElement('INPUT');
var spherePushText = document.createTextNode('Auto build Dyson Spheres \xa0\xa0\xa0\xa0\xa0');
spherePushCheckbox.setAttribute('type', 'checkbox');
spherePush.appendChild(spherePushText);
spherePush.appendChild(spherePushCheckbox);
spherePush.appendChild(linebreak12);
document.getElementById('donatingTab').appendChild(spherePush);

var AutoEMCChange = document.createElement('SPAN');
var AutoEMCChangeCheckbox = document.createElement('INPUT');
var AutoEMCChangeText = document.createTextNode('Auto convert resources with EMC \xa0\xa0\xa0\xa0\xa0');
AutoEMCChangeCheckbox.setAttribute('type', 'checkbox');
AutoEMCChange.appendChild(AutoEMCChangeText);
AutoEMCChange.appendChild(AutoEMCChangeCheckbox);
AutoEMCChange.appendChild(linebreak13);
document.getElementById('donatingTab').appendChild(AutoEMCChange);

var ConvertUranium = document.createElement('SPAN');
var ConvertUraniumCheckbox = document.createElement('INPUT');
var ConvertUraniumText = document.createTextNode('\xa0\xa0\xa0 Convert Uranium');
ConvertUraniumCheckbox.setAttribute('type', 'checkbox');
ConvertUranium.appendChild(ConvertUraniumCheckbox);
ConvertUranium.appendChild(ConvertUraniumText);
ConvertUranium.appendChild(linebreak14);
document.getElementById('donatingTab').appendChild(ConvertUranium);

var ConvertLava = document.createElement('SPAN');
var ConvertLavaCheckbox = document.createElement('INPUT');
var ConvertLavaText = document.createTextNode('\xa0\xa0\xa0 Convert Lava');
ConvertLavaCheckbox.setAttribute('type', 'checkbox');
ConvertLava.appendChild(ConvertLavaCheckbox);
ConvertLava.appendChild(ConvertLavaText);
ConvertLava.appendChild(linebreak15);
document.getElementById('donatingTab').appendChild(ConvertLava);

var ConvertOil = document.createElement('SPAN');
var ConvertOilCheckbox = document.createElement('INPUT');
var ConvertOilText = document.createTextNode('\xa0\xa0\xa0 Convert Oil');
ConvertOilCheckbox.setAttribute('type', 'checkbox');
ConvertOil.appendChild(ConvertOilCheckbox);
ConvertOil.appendChild(ConvertOilText);
ConvertOil.appendChild(linebreak16);
document.getElementById('donatingTab').appendChild(ConvertOil);

var ConvertMetal = document.createElement('SPAN');
var ConvertMetalCheckbox = document.createElement('INPUT');
var ConvertMetalText = document.createTextNode('\xa0\xa0\xa0 Convert Metal');
ConvertMetalCheckbox.setAttribute('type', 'checkbox');
ConvertMetal.appendChild(ConvertMetalCheckbox);
ConvertMetal.appendChild(ConvertMetalText);
ConvertMetal.appendChild(linebreak17);
document.getElementById('donatingTab').appendChild(ConvertMetal);

var ConvertGems = document.createElement('SPAN');
var ConvertGemsCheckbox = document.createElement('INPUT');
var ConvertGemsText = document.createTextNode('\xa0\xa0\xa0 Convert Gems');
ConvertGemsCheckbox.setAttribute('type', 'checkbox');
ConvertGems.appendChild(ConvertGemsCheckbox);
ConvertGems.appendChild(ConvertGemsText);
ConvertGems.appendChild(linebreak18);
document.getElementById('donatingTab').appendChild(ConvertGems);

var ConvertCharcoal = document.createElement('SPAN');
var ConvertCharcoalCheckbox = document.createElement('INPUT');
var ConvertCharcoalText = document.createTextNode('\xa0\xa0\xa0 Convert Charcoal');
ConvertCharcoalCheckbox.setAttribute('type', 'checkbox');
ConvertCharcoal.appendChild(ConvertCharcoalCheckbox);
ConvertCharcoal.appendChild(ConvertCharcoalText);
ConvertCharcoal.appendChild(linebreak19);
document.getElementById('donatingTab').appendChild(ConvertCharcoal);

var ConvertWood = document.createElement('SPAN');
var ConvertWoodCheckbox = document.createElement('INPUT');
var ConvertWoodText = document.createTextNode('\xa0\xa0\xa0 Convert Wood');
ConvertWoodCheckbox.setAttribute('type', 'checkbox');
ConvertWood.appendChild(ConvertWoodCheckbox);
ConvertWood.appendChild(ConvertWoodText);
ConvertWood.appendChild(linebreak20);
document.getElementById('donatingTab').appendChild(ConvertWood);

var ConvertSilicon = document.createElement('SPAN');
var ConvertSiliconCheckbox = document.createElement('INPUT');
var ConvertSiliconText = document.createTextNode('\xa0\xa0\xa0 Convert Silicon');
ConvertSiliconCheckbox.setAttribute('type', 'checkbox');
ConvertSilicon.appendChild(ConvertSiliconCheckbox);
ConvertSilicon.appendChild(ConvertSiliconText);
ConvertSilicon.appendChild(linebreak21);
document.getElementById('donatingTab').appendChild(ConvertSilicon);

var ConvertLunarite = document.createElement('SPAN');
var ConvertLunariteCheckbox = document.createElement('INPUT');
var ConvertLunariteText = document.createTextNode('\xa0\xa0\xa0 Convert Lunarite');
ConvertLunariteCheckbox.setAttribute('type', 'checkbox');
ConvertLunarite.appendChild(ConvertLunariteCheckbox);
ConvertLunarite.appendChild(ConvertLunariteText);
ConvertLunarite.appendChild(linebreak22);
document.getElementById('donatingTab').appendChild(ConvertLunarite);

var ConvertMethane = document.createElement('SPAN');
var ConvertMethaneCheckbox = document.createElement('INPUT');
var ConvertMethaneText = document.createTextNode('\xa0\xa0\xa0 Convert Methane');
ConvertMethaneCheckbox.setAttribute('type', 'checkbox');
ConvertMethane.appendChild(ConvertMethaneCheckbox);
ConvertMethane.appendChild(ConvertMethaneText);
ConvertMethane.appendChild(linebreak23);
document.getElementById('donatingTab').appendChild(ConvertMethane);

var ConvertTitanium = document.createElement('SPAN');
var ConvertTitaniumCheckbox = document.createElement('INPUT');
var ConvertTitaniumText = document.createTextNode('\xa0\xa0\xa0 Convert Titanium');
ConvertTitaniumCheckbox.setAttribute('type', 'checkbox');
ConvertTitanium.appendChild(ConvertTitaniumCheckbox);
ConvertTitanium.appendChild(ConvertTitaniumText);
ConvertTitanium.appendChild(linebreak24);
document.getElementById('donatingTab').appendChild(ConvertTitanium);

var ConvertGold = document.createElement('SPAN');
var ConvertGoldCheckbox = document.createElement('INPUT');
var ConvertGoldText = document.createTextNode('\xa0\xa0\xa0 Convert Gold');
ConvertGoldCheckbox.setAttribute('type', 'checkbox');
ConvertGold.appendChild(ConvertGoldCheckbox);
ConvertGold.appendChild(ConvertGoldText);
ConvertGold.appendChild(linebreak25);
document.getElementById('donatingTab').appendChild(ConvertGold);

var ConvertSilver = document.createElement('SPAN');
var ConvertSilverCheckbox = document.createElement('INPUT');
var ConvertSilverText = document.createTextNode('\xa0\xa0\xa0 Convert Silver');
ConvertSilverCheckbox.setAttribute('type', 'checkbox');
ConvertSilver.appendChild(ConvertSilverCheckbox);
ConvertSilver.appendChild(ConvertSilverText);
ConvertSilver.appendChild(linebreak26);
document.getElementById('donatingTab').appendChild(ConvertSilver);

var ConvertHydrogen = document.createElement('SPAN');
var ConvertHydrogenCheckbox = document.createElement('INPUT');
var ConvertHydrogenText = document.createTextNode('\xa0\xa0\xa0 Convert Hydrogen');
ConvertHydrogenCheckbox.setAttribute('type', 'checkbox');
ConvertHydrogen.appendChild(ConvertHydrogenCheckbox);
ConvertHydrogen.appendChild(ConvertHydrogenText);
ConvertHydrogen.appendChild(linebreak27);
document.getElementById('donatingTab').appendChild(ConvertHydrogen);

var ConvertHelium = document.createElement('SPAN');
var ConvertHeliumCheckbox = document.createElement('INPUT');
var ConvertHeliumText = document.createTextNode('\xa0\xa0\xa0 Convert Helium');
ConvertHeliumCheckbox.setAttribute('type', 'checkbox');
ConvertHelium.appendChild(ConvertHeliumCheckbox);
ConvertHelium.appendChild(ConvertHeliumText);
ConvertHelium.appendChild(linebreak28);
document.getElementById('donatingTab').appendChild(ConvertHelium);

var ConvertIce = document.createElement('SPAN');
var ConvertIceCheckbox = document.createElement('INPUT');
var ConvertIceText = document.createTextNode('\xa0\xa0\xa0 Convert Ice');
ConvertIceCheckbox.setAttribute('type', 'checkbox');
ConvertIce.appendChild(ConvertIceCheckbox);
ConvertIce.appendChild(ConvertIceText);
ConvertIce.appendChild(linebreak29);
document.getElementById('donatingTab').appendChild(ConvertIce);

var ConvertMeteorite = document.createElement('SPAN');
var ConvertMeteoriteCheckbox = document.createElement('INPUT');
var ConvertMeteoriteText = document.createTextNode('\xa0\xa0\xa0 Convert Meteorite');
ConvertMeteoriteCheckbox.setAttribute('type', 'checkbox');
ConvertMeteorite.appendChild(ConvertMeteoriteCheckbox);
ConvertMeteorite.appendChild(ConvertMeteoriteText);
ConvertMeteorite.appendChild(linebreak30);
document.getElementById('donatingTab').appendChild(ConvertMeteorite);

// Starting variables for building amounts

T1AmountTextBox.value = '50';
T2AmountTextBox.value = '50';
T3AmountTextBox.value = '50';
T4AmountTextBox.value = '50';
T5AmountTextBox.value = '50';

// Starting boxes checked for AutoEMCChange

ConvertUraniumCheckbox.checked = true;
ConvertMetalCheckbox.checked = true;
ConvertGemsCheckbox.checked = true;
ConvertSiliconCheckbox.checked = true;
ConvertLunariteCheckbox.checked = true;
ConvertTitaniumCheckbox.checked = true;
ConvertGoldCheckbox.checked = true;
ConvertSilverCheckbox.checked = true;
ConvertHydrogenCheckbox.checked = true;
ConvertIceCheckbox.checked = true;
ConvertMeteoriteCheckbox.checked = true;

// Create variables for storage upgrades. className will be used.
var uraniumFull = document.getElementById('uranium');
var lavaFull = document.getElementById('lava');
var oilFull = document.getElementById('oil');
var metalFull = document.getElementById('metal');
var gemFull = document.getElementById('gem');
var charcoalFull = document.getElementById('charcoal');
var woodFull = document.getElementById('wood');
var siliconFull = document.getElementById('silicon');
var lunariteFull = document.getElementById('lunarite');
var methaneFull = document.getElementById('methane');
var titaniumFull = document.getElementById('titanium');
var goldFull = document.getElementById('gold');
var silverFull = document.getElementById('silver');
var hydrogenFull = document.getElementById('hydrogen');
var heliumFull = document.getElementById('helium');
var iceFull = document.getElementById('ice');
var meteoriteFull = document.getElementById('meteorite');

// Main loop
var loop = setInterval(function() {
    increaseResources();
	upgradeStorage();
	DysonBuilder();
	LabBuilder();
	T5Builder();
	T4Builder();
	T3Builder();
	T2Builder();
	T1Builder();
	PlasmaMeteoriteBuilder();
	EnergyBuilder();
}, 500) ;

var loop2 = setInterval(function() {
	AutoEMCConvert();
	AutoEMCConvertPlasma();
}, 5000) ;

// Increase resources
function increaseResources() {
    if (GainResourcesCheckbox.checked == true) {
        var minimumPlasma = 10000;  // Minimum Plasma level to be maintained at all times
        if (energy > 150000 && meteoriteps < 300 &&  document.getElementById('plasmaNav').className != 'sideTab hidden') {
		gainResource('plasma');
        }
        if (document.getElementById('uraniumNav').className != 'sideTab hidden') {
		gainResource('uranium');
        }
        if (document.getElementById('lavaNav').className != 'sideTab hidden') {
		gainResource('lava');
        }
        if (document.getElementById('oilNav').className != 'sideTab hidden') {
		gainResource('oil');
        }
        gainResource('metal');
        gainResource('gem');
        gainResource('wood');
        if (document.getElementById('siliconNav').className != 'sideTab hidden') {
        gainResource('silicon');
        }
        if (document.getElementById('lunariteNav').className != 'sideTab hidden') {
		gainResource('lunarite');
        }
        if (document.getElementById('methaneNav').className != 'sideTab hidden') {
		gainResource('methane');
        }
        if (document.getElementById('titaniumNav').className != 'sideTab hidden') {
		gainResource('titanium');
        }
        if (document.getElementById('goldNav').className != 'sideTab hidden') {
		gainResource('gold');
        }
        if (document.getElementById('silverNav').className != 'sideTab hidden') {
		gainResource('silver');
        }
        if (document.getElementById('hydrogenNav').className != 'sideTab hidden') {
		gainResource('hydrogen');
        }
        if (document.getElementById('heliumNav').className != 'sideTab hidden') {
		gainResource('helium');
        }
        if (document.getElementById('iceNav').className != 'sideTab hidden') {
		gainResource('ice');
        }
        if (plasma > minimumPlasma && document.getElementById('meteoriteNav').className != 'sideTab hidden' ) {
		gainResource('meteorite'); // Game definied function for clicking gain button
		}
	}
}

// Upgrade storage. Full storage is indicated by green text which is changed using class.

function upgradeStorage() {
	if (ExpandStorageCheckbox.checked == true && Game.tech.isPurchased('unlockStorage')) {
		if (uraniumFull.className == 'green') {
			upgradeUraniumStorage(); // Game defined function
		}
		if (lavaFull.className == 'green') {
			upgradeLavaStorage();
		}
		if (oilFull.className == 'green') {
			upgradeOilStorage();
		}
		if (metalFull.className == 'green') {
			upgradeMetalStorage();
		}
		if (gemFull.className == 'green') {
			upgradeGemStorage();
		}
		if (charcoalFull.className == 'green') {
			upgradeCharcoalStorage();
		}
		if (woodFull.className == 'green') {
			upgradeWoodStorage();
		}
		if (siliconFull.className == 'green') {
			upgradeSiliconStorage();
		}
		if (lunariteFull.className == 'green') {
			upgradeLunariteStorage();
		}
		if (methaneFull.className == 'green') {
			upgradeMethaneStorage();
		}
		if (titaniumFull.className == 'green') {
			upgradeTitaniumStorage();
		}
		if (goldFull.className == 'green') {
			upgradeGoldStorage();
		}
		if (silverFull.className == 'green') {
			upgradeSilverStorage();
		}
		if (hydrogenFull.className == 'green') {
			upgradeHydrogenStorage();
		}
		if (heliumFull.className == 'green') {
			upgradeHeliumStorage();
		}
		if (iceFull.className == 'green') {
			upgradeIceStorage();
		}
		if (meteoriteFull.className == 'green') {
			upgradeMeteoriteStorage();
		}
	}
}

//Dyson and related
function DysonBuilder() {
	if (spherePushCheckbox.checked == true && Game.tech.isPurchased('unlockDysonSphere') != true || sphere > Game.interstellar.stars.systemsConquered || swarm < 35 ) {
		spherePushCheckbox.checked = false;
}
	if (Game.tech.isPurchased('unlockDyson') && DSBuilderCheckbox.checked == true && spherePushCheckbox.checked != true) {
		if (ring < 20) {
			buildDysonTo(50);
			buildRing();
		}
		if (ring >= 20 && spherePushCheckbox.checked == false) {
			buildDysonTo(100);
			buildSwarm();
		}
    }   else if (Game.tech.isPurchased('unlockDysonSphere') && spherePushCheckbox.checked == true) {
            buildDysonTo(250);
            buildSphere();
	}
}


// Research
function LabBuilder() {
    var tierOneBuildingAmount = T1AmountTextBox.value;
    var tierTwoBuildingAmount = T2AmountTextBox.value;
	var tierThreeBuildingAmount = T3AmountTextBox.value;
    var tierFourBuildingAmount = T4AmountTextBox.value;
    var tierFiveBuildingAmount = T5AmountTextBox.value;
	if (SciBuilderCheckbox.checked == true) {

		if (lab < tierOneBuildingAmount) {
		getLab();
		}
		if (Game.tech.isPurchased('unlockLabT2') && labT2 < tierTwoBuildingAmount) {
		getLabT2();
		}
		if (Game.tech.isPurchased('unlockLabT3') && labT3 < tierThreeBuildingAmount) {
		getLabT3();
		}
		if (Game.tech.isPurchased('unlockLabT4') && labT4 < tierFourBuildingAmount) {
		getLabT4();
		}
        if (document.getElementById('efficiencyResearch').className != 'hidden') {
		purchaseTech('efficiencyResearch');
        }
		if (labT4 > 25) {
		var current = Game.tech.getTechData('energyEfficiencyResearch');

			if (current.current < current.maxLevel && document.getElementById('energyEfficiencyResearch').className != 'hidden') {
			purchaseTech('energyEfficiencyResearch');
			}
            if (document.getElementById('scienceEfficiencyResearch').className != 'hidden') {
			purchaseTech('scienceEfficiencyResearch');
            }
			if (getMaxEnergy() > 100000000 && document.getElementById('batteryEfficiencyResearch').className != 'hidden') {
			purchaseTech('batteryEfficiencyResearch');
			}
		}
		if (document.getElementById('labTier5').className != 'hidden' && labT5 < tierFiveBuildingAmount) {
		getLabT5();
		}
	}
}



//Plasma & Metiorite Builder
function PlasmaMeteoriteBuilder () {
	var tierOneBuildingAmount = T1AmountTextBox.value;
	var tierTwoBuildingAmount = T2AmountTextBox.value;
	var tierThreeBuildingAmount = T3AmountTextBox.value;
	if (PMBuilderCheckbox.checked == true) {
		if (bath < tierThreeBuildingAmount && energyps > 500000) {
		getBath ();
		}
		if (plasmatic < tierTwoBuildingAmount && energyps > 50000) {
		getPlasmatic ();
		}
		if (heater < tierOneBuildingAmount && energyps > 5000) {
		getHeater ();
		}


		if (smasher < tierThreeBuildingAmount && plasmaps > 1000) {
		getSmasher ();
		}
		if (web < tierTwoBuildingAmount && plasmaps > 500) {
		getWeb ();
		}
		if (printer < tierOneBuildingAmount && plasmaps > 50) {
		getPrinter ();
		}
	}
}
// Tier 1 Buildings
function T1Builder() {
	var tierOneBuildingAmount = T1AmountTextBox.value;
	if (achievementBuilderCheckbox.checked == true) {

		if (pump < tierOneBuildingAmount && document.getElementById('oilNav').className != 'sideTab hidden') {
			getPump();
		}
		if (grinder < tierOneBuildingAmount && uraniumps < hydrogenps && document.getElementById('uraniumNav').className != 'sideTab hidden') {
			getGrinder();
		}
		if (crucible < tierOneBuildingAmount && lavaps < heliumps && document.getElementById('lavaNav').className != 'sideTab hidden') {
			getCrucible();
		}
		if (miner < tierOneBuildingAmount) {
			getMiner();
		}
		if (gemMiner < tierOneBuildingAmount) {
			getGemMiner();
		}
		if (woodburner < tierOneBuildingAmount && woodps > 100 && charcoalps < 50 && document.getElementById('charcoalNav').className != 'sideTab hidden') {
			getWoodburner();
		}
		if (woodcutter < tierOneBuildingAmount) {
			getWoodcutter();
		}
		if (blowtorch < tierOneBuildingAmount && document.getElementById('siliconNav').className != 'sideTab hidden') {
			getBlowtorch();
		}
		if (moonWorker < tierOneBuildingAmount && document.getElementById('lunariteNav').className != 'sideTab hidden') {
			getMoonWorker();
		}
		if (vacuum < tierOneBuildingAmount && document.getElementById('methaneNav').className != 'sideTab hidden') {
			getVacuum();
		}
		if (explorer < tierOneBuildingAmount && document.getElementById('titaniumNav').className != 'sideTab hidden') {
			getExplorer();
		}
		if (droid < tierOneBuildingAmount && document.getElementById('goldNav').className != 'sideTab hidden') {
			getDroid();
		}
		if (scout < tierOneBuildingAmount && document.getElementById('silverNav').className != 'sideTab hidden') {
			getScout();
		}
		if (collector < tierOneBuildingAmount && document.getElementById('hydrogenNav').className != 'sideTab hidden') {
			getCollector();
		}
		if (drone < tierOneBuildingAmount && document.getElementById('heliumNav').className != 'sideTab hidden') {
			getDrone();
		}
		if (icePick < tierOneBuildingAmount && document.getElementById('iceNav').className != 'sideTab hidden') {
			getIcePick();
		}
	}
}

// 2 Tier
function T2Builder() {
	var tierTwoBuildingAmount = T2AmountTextBox.value;
	if (achievementBuilderCheckbox.checked == true && energyps > 500  && Game.tech.isPurchased('unlockMachines')) {
				if (cubic < tierTwoBuildingAmount && uraniumps < hydrogenps && uraniumps < hydrogenps && document.getElementById('uraniumNav').className != 'sideTab hidden') {
			getCubic();
		}
		if (extractor < tierTwoBuildingAmount && lavaps < heliumps && uraniumps < hydrogenps && document.getElementById('lavaNav').className != 'sideTab hidden') {
			getExtractor();
		}
		if (pumpjack < tierTwoBuildingAmount) {
			getPumpjack();
		}
		if (heavyDrill < tierTwoBuildingAmount) {
			getHeavyDrill();
		}
		if (advancedDrill < tierTwoBuildingAmount) {
			getAdvancedDrill();
		}
		if (furnace < tierTwoBuildingAmount && woodps > 1000 && charcoalps < 500) {
			getFurnace();
		}
		if (laserCutter < tierTwoBuildingAmount) {
			getLaserCutter();
		}
		if (scorcher < tierTwoBuildingAmount && document.getElementById('siliconNav').className != 'sideTab hidden') {
			getScorcher();
		}
		if (moonDrill < tierTwoBuildingAmount && document.getElementById('lunariteNav').className != 'sideTab hidden') {
			getMoonDrill();
		}
		if (suctionExcavator < tierTwoBuildingAmount && document.getElementById('methaneNav').className != 'sideTab hidden') {
			getSuctionExcavator();
		}
		if (lunariteDrill < tierTwoBuildingAmount && document.getElementById('titaniumNav').className != 'sideTab hidden') {
			getLunariteDrill();
		}
		if (destroyer < tierTwoBuildingAmount && document.getElementById('goldNav').className != 'sideTab hidden') {
			getDestroyer();
		}
		if (spaceLaser < tierTwoBuildingAmount && document.getElementById('silverNav').className != 'sideTab hidden') {
			getSpaceLaser();
		}
		if (magnet < tierTwoBuildingAmount && document.getElementById('hydrogenNav').className != 'sideTab hidden') {
			getMagnet();
		}
		if (tanker < tierTwoBuildingAmount && document.getElementById('heliumNav').className != 'sideTab hidden') {
			getTanker();
		}
		if (iceDrill < tierTwoBuildingAmount && iceps < goldps && document.getElementById('iceNav').className != 'sideTab hidden') {
			getIceDrill();
		}
	}
}

// 3 Tier
function T3Builder() {
	var tierThreeBuildingAmount = T3AmountTextBox.value;
	if (achievementBuilderCheckbox.checked == true && energyps > 1000) {

		if (enricher < tierThreeBuildingAmount && uranium > 50000000  && uraniumps < hydrogenps && document.getElementById('uraniumTier3').className != 'hidden') {
			getEnricher();
		}
		if (extruder < tierThreeBuildingAmount && lava > 50000000 && lavaps < heliumps && document.getElementById('lavaTier3').className != 'hidden') {
			getExtruder();
		}
		if (oilField < tierThreeBuildingAmount && document.getElementById('oilTier3').className != 'hidden') {
			getOilField();
		}
		if (gigaDrill < tierThreeBuildingAmount && document.getElementById('metalTier3').className != 'hidden') {
			getGigaDrill();
		}
		if (diamondDrill < tierThreeBuildingAmount && document.getElementById('gemTier3').className != 'hidden') {
			getDiamondDrill();
		}
		if (kiln < tierThreeBuildingAmount && woodps > 10000 && charcoalps < 5000 && document.getElementById('charcoalTier3').className != 'hidden') {
			getKiln();
		}
		if (deforester < tierThreeBuildingAmount && document.getElementById('woodTier3').className != 'hidden') {
			getDeforester();
		}
		if (annihilator < tierThreeBuildingAmount && document.getElementById('siliconTier3').className != 'hidden') {
			getAnnihilator();
		}
		if (moonQuarry < tierThreeBuildingAmount && document.getElementById('lunariteTier3').className != 'hidden') {
			getMoonQuarry();
		}
		if (spaceCow < tierThreeBuildingAmount && document.getElementById('methaneTier3').className != 'hidden') {
			getSpaceCow();
		}
		if (pentaDrill < tierThreeBuildingAmount && document.getElementById('titaniumTier3').className != 'hidden') {
			getPentaDrill();
		}
		if (deathStar < tierThreeBuildingAmount && document.getElementById('goldTier3').className != 'hidden') {
			getDeathStar();
		}
		if (bertha < tierThreeBuildingAmount && document.getElementById('silverTier3').className != 'hidden') {
			getBertha();
		}
		if (eCell < tierThreeBuildingAmount && hydrogen > 50000000 && document.getElementById('hydrogenTier3').className != 'hidden') {
			getECell();
		}
		if (compressor < tierThreeBuildingAmount && helium > 50000000 && document.getElementById('heliumTier3').className != 'hidden') {
			getCompressor();
		}
		if (freezer < tierThreeBuildingAmount && ice > 50000000 && iceps < goldps && document.getElementById('iceTier3').className != 'hidden') {
			getFreezer();
		}
	}
}

// 4 Tier
function T4Builder() {
	var tierFourBuildingAmount = T4AmountTextBox.value;
	if (achievementBuilderCheckbox.checked == true && energyps > 10000 && meteoriteps > 20 && meteoriteStorage > 5000) {

		if (recycler < tierFourBuildingAmount && uraniumps < hydrogenps && document.getElementById('uraniumTier4').className != 'hidden') {
			getRecycler();
		}
		if (veluptuator < tierFourBuildingAmount && lavaps < heliumps && document.getElementById('lavaTier4').className != 'hidden') {
			getVeluptuator();
		}
		if (oilRig < tierFourBuildingAmount) {
			getOilRig();
		}
		if (quantumDrill < tierFourBuildingAmount) {
			getQuantumDrill();
		}
		if (carbyneDrill < tierFourBuildingAmount) {
			getCarbyneDrill();
		}
		if (fryer < tierFourBuildingAmount && woodps > 50000 && charcoalps < 10000) {
			getFryer();
		}
		if (infuser < tierFourBuildingAmount) {
			getInfuser();
		}
		if (desert < tierFourBuildingAmount) {
			getDesert();
		}
		if (planetExcavator < tierFourBuildingAmount) {
			getPlanetExcavator();
		}
		if (vent < tierFourBuildingAmount) {
			getVent();
		}
		if (titanDrill < tierFourBuildingAmount) {
			getTitanDrill();
		}
		if (actuator < tierFourBuildingAmount) {
			getActuator();
		}
		if (cannon < tierFourBuildingAmount) {
			getCannon();
		}
		if (hindenburg < tierFourBuildingAmount) {
			getHindenburg();
		}
		if (skimmer < tierFourBuildingAmount) {
			getSkimmer();
		}
		if (mrFreeze < tierFourBuildingAmount && iceps < goldps) {
			getMrFreeze();
		}
	}
}

// 5 Tier
function T5Builder() {
	var tierFiveBuildingAmount = T5AmountTextBox.value;
	if (achievementBuilderCheckbox.checked == true && energyps > 100000 && meteoriteps > 50 && meteoriteStorage > 25000) {

		if (planetNuke < tierFiveBuildingAmount && uraniumps < hydrogenps) {
			getPlanetNuke ();
		}
		if (condensator < tierFiveBuildingAmount && lavaps < heliumps) {
			getCondensator ();
		}
		if (fossilator < tierFiveBuildingAmount && oilps < metalps) {
			getFossilator ();
		}
		if (multiDrill < tierFiveBuildingAmount) {
			getMultiDrill ();
		}
		if (diamondChamber < tierFiveBuildingAmount) {
			getDiamondChamber ();
		}
		if (microPollutor < tierFiveBuildingAmount && woodps > 100000 && charcoalps < 50000) {
			getMicroPollutor ();
		}
		if (forest < tierFiveBuildingAmount) {
			getForest ();
		}
		if (tardis < tierFiveBuildingAmount) {
			getTardis ();
		}
		if (cloner < tierFiveBuildingAmount) {
			getCloner ();
		}
		if (interCow < tierFiveBuildingAmount && methaneps < iceps) {
			getInterCow ();
		}
		if (club < tierFiveBuildingAmount) {
			getClub ();
		}
		if (philosopher < tierFiveBuildingAmount) {
			getPhilosopher ();
		}
		if (werewolf < tierFiveBuildingAmount) {
			getWerewolf ();
		}
		if (harvester < tierFiveBuildingAmount && hydrogenps < lunariteps) {
			getHarvester ();
		}
		if (cage < tierFiveBuildingAmount && heliumps < lunariteps) {
			getCage ();
		}
		if (overexchange < tierFiveBuildingAmount) {
			getOverexchange ();
		}
	}
}

//Energy Production Buidling to start with
function EnergyBuilder() {
	var tierOneBuildingAmount = T1AmountTextBox.value;
	var tierTwoBuildingAmount = T2AmountTextBox.value;
	var tierThreeBuildingAmount = T3AmountTextBox.value;
	if (achievementBuilderCheckbox.checked == true && document.getElementById('energyNav').className != 'sideTab hidden') {

		if (charcoalEngine < tierOneBuildingAmount && Game.tech.isPurchased('unlockBasicEnergy')) {
			getCharcoalEngine();
		}
		if (solarPanel < tierOneBuildingAmount && Game.tech.isPurchased('unlockSolar')) {
			getSolarPanel();
		}
		if (methaneStation < tierTwoBuildingAmount) {
			getMethaneStation();
		}
		if (nuclearStation < tierThreeBuildingAmount) {
			getNuclearStation();
		}
		if (magmatic < tierThreeBuildingAmount) {
			getMagmatic();
		}
		if (fusionReactor < tierThreeBuildingAmount) {
			getFusionReactor();
		}
	}
}

function AutoEMCConvert() {
	if (Game.tech.isPurchased('unlockEmc') && AutoEMCChangeCheckbox.checked == true) {
		if (uranium < uraniumStorage && ConvertUraniumCheckbox.checked == true) {
			convertEnergy('uranium');
		}
		if (lava < lavaStorage && ConvertLavaCheckbox.checked == true) {
			convertEnergy('lava');
		}
		if (oil < oilStorage && ConvertOilCheckbox.checked == true) {
			convertEnergy('oil');
		}
		if (metal < metalStorage && ConvertMetalCheckbox.checked == true) {
			convertEnergy('metal');
		}
		if (gem < gemStorage && ConvertGemsCheckbox.checked == true) {
			convertEnergy('gem');
		}
		if (charcoal < charcoalStorage && ConvertCharcoalCheckbox.checked == true) {
			convertEnergy('charcoal');
		}
		if (wood < woodStorage && ConvertWoodCheckbox.checked == true) {
			convertEnergy('wood');
		}
		if (silicon < siliconStorage && ConvertSiliconCheckbox.checked == true) {
			convertEnergy('silicon');
		}
		if (lunarite < lunariteStorage && ConvertLunariteCheckbox.checked == true) {
			convertEnergy('lunarite');
		}
		if (methane < methaneStorage && ConvertMethaneCheckbox.checked == true) {
			convertEnergy('methane');
		}
		if (titanium < titaniumStorage && ConvertTitaniumCheckbox.checked == true) {
			convertEnergy('titanium');
		}
		if (gold < goldStorage && ConvertGoldCheckbox.checked == true) {
			convertEnergy('gold');
		}
		if (silver < silverStorage && ConvertSilverCheckbox.checked == true) {
			convertEnergy('silver');
		}
		if (hydrogen < hydrogenStorage && ConvertHydrogenCheckbox.checked == true) {
			convertEnergy('hydrogen');
		}
		if (helium < heliumStorage && ConvertHeliumCheckbox.checked == true) {
			convertEnergy('helium');
		}
		if (ice < iceStorage && ConvertIceCheckbox.checked == true) {
			convertEnergy('ice');
		}
	}
}

function AutoEMCConvertPlasma() {
	if (Game.tech.isPurchased('unlockEmc') && ConvertMeteoriteCheckbox.checked == true && AutoEMCChangeCheckbox.checked == true) {
		if (meteorite < meteoriteStorage) {
			convertPlasma('meteorite');
		}
	}
}