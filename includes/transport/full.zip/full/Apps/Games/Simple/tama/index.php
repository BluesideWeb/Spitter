<?php 
	    $hm = "/var/www/html/Admin/HVT_2_0"; 
	    $hm2 = "http://brodie.local/Admin/HVT_2_0"; 
	    include "$hm/ipWriter.php";
        ?>
<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=1, charset="utf-8"/>
    	<style> body {padding: 0; margin: 0;} </style>
    	<script src="js/phaser.js"></script>
		<script src="js/userInterface.js"></script>
    	<script src="js/food.js"></script>
		<script src="js/play.js"></script>
		<script src="js/shop.js"></script>
		<script src="js/save.js"></script>
		<script src="js/settings.js"></script>
		<script src="js/game.js"></script>
  </head>
  <body>
  </body>
</html>
